//**************************************************************
// Author: Chris Thomas
// Date: 5/21/2022
// Assignment: Lab 6 - Shells Part 1
// Modifications: N/A
//
// *************************************************************

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define PROMPT "cmd> "
#define DELIMS " \n\t\r"

int main()
{
    char line[256];
    char *token[50];                                                            //array for holding args
    char *command;                                                              //char for holding exec command
    int i = 0;
    int pid;
    printf(PROMPT);                                                             //print the prompt
    while (fgets(line, sizeof(line), stdin) != NULL)                            //get entire line entered
    {
        command = strtok(line, DELIMS);                                         //get first word
        if (strcmp(command, "exit") == 0)                                       //check if exit was entered
        {
            printf("Exiting\n");                                                //print Exiting
            exit(0);                                                            //exit program
        }
        else if (strcmp(command, "chdir") == 0 || strcmp(command, "cd") == 0)   //check for chdir or cd command
        {
            command = strtok(NULL, DELIMS);                                     //put directory in command
            chdir(command);                                                     //call chdir with directory as paramater
        }
        else
        {
            while (command != NULL)                                             //go through whole line
            {
                token[i] = command;                                             //store args in array
                command = strtok(NULL, DELIMS);                                 //move to next word
                i++;                                                            //increment i
            }
            token[i] = NULL;                                                    //add NULL on end of array

            pid = fork();                                                       //fork
            if (pid == 0)
            {
                execvp(token[0], token);                                        //run exec
                printf("Failed to load program\n");                             //error message
                exit(1);
            }
            else
            {
                wait(NULL);                                                     //wait to prevent forkbomb
            }
        }
        i = 0;                                                                  //set i to 0 for array
        printf(PROMPT);                                                         //prompt again
    }
    return 0;
}
