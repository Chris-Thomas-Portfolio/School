//********************************************
// Definitin of a thread-safe sequence number
// Author: Phil Howard
//

#include "sequence.h"

static int g_sequence = 0;

// Return the next number in the sequence.
int Next_In_Sequence()
{
    return ++g_sequence;
}
