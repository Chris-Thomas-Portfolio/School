//***************************************************
// Beginning of the test program for a thread-safe list
//
// Author Phil Howard

#include <stdio.h>

#include "list.h"
#include "sequence.h"

typedef struct
{
    int thread_number;
    int num_inserts;
    linked_list_t list;
} params_type;

//*******************************************************
static void *Insert_Data(void *p)
{
    params_type *params = (params_type *)p;

    printf("Thread %d started\n", params->thread_number);

    for (int ii=0; ii<params->num_inserts; ii++)
    {
        Insert_In_Order(params->list, Next_In_Sequence());
    }

    printf("Thread %d inserted %d values\n", 
            params->thread_number, params->num_inserts);

    return NULL;
}

//*******************************************************
void print_value(int value)
{
    printf("%d\n", value);
}

//*******************************************************
void check_values(int value)
{
    static int last_value = 0;

    if (value == last_value)
    {
        fprintf(stderr, "Duplicate value: %d\n", value);
    }
    else if (value < last_value)
    {
        fprintf(stderr, "Out of order value: %d\n", value);
    }
    else if (value > last_value + 1)
    {
        fprintf(stderr, "Skipped  valueis: %d %d\n", last_value, value);
    }

    last_value = value;
}    

//*******************************************************
int main()
{
    linked_list_t list = Init_List();

    params_type params;
    params.thread_number = 1;
    params.num_inserts = 10;
    params.list = list;

    Insert_Data(&params);

    printf("There are %d items in the list\n", Count(list));

    Traverse(list, check_values);

    Delete_List(list);

    printf("Done\n");

    return 0;
}
