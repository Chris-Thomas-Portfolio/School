//********************************************
// Declaration of a thread-safe sequence number
// Author: Phil Howard
//

// Return the next number in the sequence.
int Next_In_Sequence();

