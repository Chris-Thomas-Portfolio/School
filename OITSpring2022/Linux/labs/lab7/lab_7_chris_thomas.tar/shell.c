//**************************************************************
// Author: Chris Thomas
// Date: 5/23/2022
// Assignment: Lab 7 - Shells Part 2
// Modifications: N/A
//
// *************************************************************

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>

#define PROMPT "cmd> "
#define DELIMS " \n\t\r"
//************************************************************
// Purpose: Process and execute the command.
//
// Function: Duplicates input and output and then runs
//           after forking.
//
//************************************************************            
void process_command(char **args, int input, int output)
{
    int pid;
    pid = fork();                                                       //fork
    if (pid == 0)
    {
        dup2(input, 0);
        dup2(output, 1);
        execvp(args[0], args);                                        //run exec
        printf("Failed to load program\n");                             //error message
        exit(1);
    }
    else
    {
        wait(NULL);                                                     //wait to prevent forkbomb
    }
}

int main()
{
    char line[256];
    char *args[50];                                                            //array for holding args
    char *word;                                                              //char for holding exec word
    int i = 0;
    int pipefd[2];
    int input = 0;
    int output = 1;
    int eflag = 0;
    int redirectflag = 0;
    int rflag = 0;
    printf(PROMPT);                                                             //print the prompt

    while (fgets(line, sizeof(line), stdin) != NULL)                            //get entire line entered
    {
        word = strtok(line, DELIMS);                                         //get first word
        if (strcmp(word, "exit") == 0)                                       //check if exit was entered
        {
            printf("Exiting\n");                                                //print Exiting
            exit(0);                                                            //exit program
        }
        else if (strcmp(word, "chdir") == 0 || strcmp(word, "cd") == 0)   //check for chdir or cd word
        {
            word = strtok(NULL, DELIMS);                                     //put directory in word
            chdir(word);                                                     //call chdir with directory as paramater
        }
        else
        {
            input = 0;
            output = 1;
            eflag = 0;
            redirectflag = 0;


            while (word != NULL)                                             //go through whole line
            {
                if (strcmp(word, "<") == 0)
                {
                    if(rflag != 0)
                    {
                        fprintf(stdout, "Cant redirect after first command.\n");    //make sure they are not trying to redirct after first command if so set error flag
                        eflag = 1;
                    }
                    else
                    {
                        word = strtok(NULL, DELIMS);        
                        input = open(word, O_RDONLY);                               //input set to name given
                    }
                }
                else if(strcmp(word, ">") == 0)
                {
                    word = strtok(NULL, DELIMS);    
                    redirectflag = 1;                                               //enable redirectflag
                    output = open(word, O_WRONLY | O_CREAT | O_TRUNC, 0644);        //set output to name given
                }
                else if(strcmp(word, "|") == 0)                                     //check for pipe
                {
                    if(redirectflag)
                    {
                        fprintf(stdout, "Cant pipe after redirection");             //make sure they are not trying to pipe right after redirection if so send out error and enable error flag
                        eflag = 1;
                    }
                    else
                    {
                        pipe(pipefd);                                           //create pipe
                        output = pipefd[1];                                     //set output
                        args[i] = NULL;                                         //add NULL to end of args array
                        process_command(args, input, output);                   //call process_command function
                        rflag++;                                                //increment rflag for check of valid redirection
                        input = pipefd[0];                                      //set input
                        close(output);                                          //close output
                        i = 0;                                                  //reset i
                    }
                }
                else
                {
                    args[i] = word;                                             //store args in array
                    i++;                                                        //increment i
                }
                word = strtok(NULL, DELIMS);                                 //move to next word
            }
            if(!eflag)
            {
                args[i] = NULL;
                if(!redirectflag)                                               //check for redirection
                {
                    output = 1;
                }
                process_command(args, input, output);
            }
        }
        i = 0;                                                                  //set i to 0 for array
        printf(PROMPT);                                                         //prompt again
    }
    return 0;
}
